﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace serverrockpaper
{
    internal class Program
    {
        static BinaryFormatter binaryFormatter;
        static NetworkStream ns1;
        static NetworkStream ns2;
        static void Main(string[] args)
        {
            TcpListener listner = new TcpListener(9270);
            listner.Start();
            TcpClient player1 = listner.AcceptTcpClient();
            Console.WriteLine("Playyer 1 connected");
            TcpClient player2 = listner.AcceptTcpClient();
            Console.WriteLine("Playyer 2 connected");
            ns1 = player1.GetStream();
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(ns1, "you are playyer 1");
            binaryFormatter.Serialize(ns1, "you are playyer 2");
            ns2 = player2.GetStream();
            Thread th1 = new Thread(start);
            Thread th2 = new Thread(start);
            th1.Start();
            th2.Start();
            th1.Join();
            th2.Join();
            //    //here i will send it to second playyer

            //    string req1=(string)binaryFormatter.Deserialize(ns1);
            //    // string req2 = (string)binaryFormatter.Deserialize(ns2);
            //    if (req1 ==null)
            //    {
            //       listner.Stop();
            //    }
            //    else if (req1 == "Restart")
            //    {
            //       start(); 
            //    }


            //    Console.ReadLine();

        }
        private static void start()
        {
            for (int i = 0; i < 6; i++)
            {
                string playerchoise = (string)binaryFormatter.Deserialize(ns1);
                Console.WriteLine(playerchoise);
                binaryFormatter.Serialize(ns2, playerchoise);

                string player2choise = (string)binaryFormatter.Deserialize(ns2);
                Console.WriteLine(playerchoise);
                binaryFormatter.Serialize(ns1, player2choise);
            }
        }

    }
}

