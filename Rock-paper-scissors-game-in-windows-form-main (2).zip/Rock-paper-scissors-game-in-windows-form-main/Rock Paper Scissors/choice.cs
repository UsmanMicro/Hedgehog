﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rock_Paper_Scissors
{
    public partial class choice : Form
    {
        public choice()
        {
            InitializeComponent();
        }

        private void btnCpu_Click(object sender, EventArgs e)
        {
            playwithcpu cpu = new playwithcpu();
            cpu.Show();
            this.Hide();
        }

        private void btnplayer_Click(object sender, EventArgs e)
        {   
            login lo = new login();
            lo.Show();
            this.Hide();
        }
    }
}
