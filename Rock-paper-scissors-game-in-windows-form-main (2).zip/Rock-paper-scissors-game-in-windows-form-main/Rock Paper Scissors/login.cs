﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rock_Paper_Scissors
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1(txtName.Text,txtIp.Text,int.Parse(txtPort.Text));
            form1.Show();
            this.Hide();
        }
    }
}
