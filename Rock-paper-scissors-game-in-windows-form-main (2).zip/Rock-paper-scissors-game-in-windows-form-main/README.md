# C# Rock paper scissors tutorial in visual studio with windows form
In this tutorial we are making a simple rock paper scissors game which plays against the CPU. You can make 3 choices using buttons and then CPU will make the same choices in the background.   We are using click events, timer events and custom functions to make this game work. You can follow along as we make this game step by step and you can also use your own images or theories to make the game.   In the background of the programming we are using If statements, Switch Statements, Boolean, string, integers and Arrays to conduct the logic of the game. Every part of the code is explained in this video and if you have any questions about this at all leave it in the comments here or on the MOOICT website. Either way I will check it and get back to you. 


Video Tutorial -

[![](http://img.youtube.com/vi/9FSW8qU60x8/0.jpg)](http://www.youtube.com/watch?v=9FSW8qU60x8 "MOO ICT rock paper scissors game in windows form and c sharp")



Written Tutorial - 
https://www.mooict.com/c-tutorial-create-a-rock-paper-and-scissors-game/
